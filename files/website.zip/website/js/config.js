window._config = {
    cognito: {
        userPoolId: '', // chapter 2)  e.g. ap-northeast-2_uXboG5pAb
        userPoolClientId: '', // chapter 2) e.g. 25ddkmj4v6hfsfvruhpfi7n4hv
        region: 'ap-northeast-2' // chapter 2) e.g. ap-northeast-2
    },
    api: {
        invokeUrl: '' // chapter 3) e.g. https://rc7nyt4tql.execute-api.ap-northeast-2.amazonaws.com/prod',
    }
};